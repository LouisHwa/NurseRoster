import boto3
import json
from datetime import datetime
import traceback
import re

# --- AWS Clients ---
s3 = boto3.client("s3")
agent_runtime = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

# --- Config ---
BUCKET_NAME = "hospital-roster-data"
FILES = {
    "nurse": "raw_data/nurse_data/nurse.json",
    "demand": "raw_data/demand_data/demand.json"
}

AGENT_ID = "WLF7TDIXYX"
AGENT_ALIAS_ID = "GYFNL2ISET"

def lambda_handler(event, context):
    try:
        # Determine if triggered by S3 or direct test
        if "Records" in event:
            # Triggered by S3 event
            record = event["Records"][0]
            s3_key = record["s3"]["object"]["key"]
            
            obj = s3.get_object(Bucket=BUCKET_NAME, Key=s3_key)
            payload = json.loads(obj["Body"].read().decode("utf-8"))
        else:
            # Triggered directly (manual test)
            payload = event

        # --- Extract fields from payload ---
        target_file = payload.get("target_file")
        nurse_id = payload.get("nurse_id")
        nurse_ids = payload.get("nurse_ids")
        instruction = payload.get("instruction")

        # --- Determine target nurse IDs ---
        target_nurse_ids = []
        if nurse_ids:
            target_nurse_ids = nurse_ids if isinstance(nurse_ids, list) else [nurse_ids]
        elif nurse_id:
            if isinstance(nurse_id, list):
                target_nurse_ids = nurse_id
            elif isinstance(nurse_id, str) and "," in nurse_id:
                target_nurse_ids = [nid.strip() for nid in nurse_id.split(",")]
            else:
                target_nurse_ids = [nurse_id]

        if not target_file or target_file not in FILES:
            return _response("❌ Invalid target_file. Must be 'nurse' or 'demand'.")

        # --- Load original data ---
        file_key = FILES[target_file]
        original_obj = s3.get_object(Bucket=BUCKET_NAME, Key=file_key)
        original_data = json.loads(original_obj["Body"].read().decode("utf-8"))
        original_count = _count_records(original_data)

        # --- Create backup ---
        backup_key = f"backups/{target_file}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=backup_key,
            Body=json.dumps(original_data, indent=2).encode("utf-8")
        )

        # --- Update data ---
        if target_file == "nurse":
            if target_nurse_ids:
                if len(target_nurse_ids) == 1:
                    updated_data = _update_single_nurse(original_data, target_nurse_ids[0], instruction)
                else:
                    updated_data = _update_multiple_nurses(original_data, target_nurse_ids, instruction)
                updated_items = target_nurse_ids
            else:
                return _response("❌ Nurse update requires 'nurse_id' or 'nurse_ids'.")
        elif target_file == "demand":
            updated_data = _update_demand(original_data, instruction)
            updated_items = ["demand"]

        # --- Validate count (only for nurse updates) ---
        if target_file == "nurse":
            updated_count = _count_records(updated_data)
            if updated_count != original_count:
                return _response(f"❌ Data integrity check failed! Original: {original_count}, Updated: {updated_count}")

        # --- Save updated data ---
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=file_key,
            Body=json.dumps(updated_data, indent=2).encode("utf-8")
        )

        return _response(
            message=f"✅ Updated {target_file} successfully: {', '.join(updated_items)}",
            backup_created=backup_key,
            original_count=original_count if target_file=="nurse" else None,
            updated_count=updated_count if target_file=="nurse" else None,
            instruction_executed=instruction
        )

    except Exception as e:
        traceback.print_exc()
        return _response(f"❌ Error: {str(e)}")


# --- Nurse Update Functions ---
def _update_single_nurse(original_data, nurse_id, instruction):
    target_nurse = _find_nurse(original_data, nurse_id)
    if not target_nurse:
        raise Exception(f"Nurse {nurse_id} not found")

    prompt = f"""
You are updating a single nurse record. Return ONLY the updated nurse object as valid JSON. Always shortform the name of the days. Monday -> Mon. Tuesday -> Tue. Wednesday -> Wed.
Always format the times into "[Day]-[Shift]". If there is a colon, remove the suffix. For example, get "Mon-Morning" from "Mon-Morning:2025-05-04 to 2025-06-04".
If the following keywords are mentioned, ["leave", "annual", "sick", "maternity"]. Assume that it takes all day, so format the times to "[Day]-AllDay".

Instruction: {instruction}

Current nurse record:
{json.dumps(target_nurse, indent=2)}

Return only the updated nurse object with all original fields preserved, only changing what the instruction specifies.
"""
    updated_nurse = _call_bedrock_agent(prompt, f"single-{nurse_id}")
    try:
        updated_nurse_obj = json.loads(updated_nurse)
    except json.JSONDecodeError as e:
        raise Exception(f"Bedrock returned invalid JSON: {e}")

    return _replace_nurse_in_dataset(original_data, nurse_id, updated_nurse_obj)


def _update_multiple_nurses(original_data, nurse_ids, instruction):
    target_nurses = {nid: _find_nurse(original_data, nid) for nid in nurse_ids}
    if None in target_nurses.values():
        missing = [nid for nid, val in target_nurses.items() if val is None]
        raise Exception(f"Nurses not found: {', '.join(missing)}")

    prompt = f"""
You are updating multiple nurse records. Return ONLY a JSON array of the updated nurse objects. Always shortform the name of the days. Monday -> Mon. Tuesday -> Tue. Wednesday -> Wed.
Always format the times into "[Day]-[Shift]". If there is a colon, remove the suffix. For example, get "Mon-Morning" from "Mon-Morning:2025-05-04 to 2025-06-04".
If the following keywords are mentioned, ["leave", "annual", "sick", "maternity"]. Assume that it takes all day, so format the times to "[Day]-AllDay".

Instruction: {instruction}

Current nurse records:
{json.dumps(list(target_nurses.values()), indent=2)}

Return a JSON array with all nurses updated according to the instruction. Preserve all original fields, only change what the instruction specifies.
"""
    updated_nurses_text = _call_bedrock_agent(prompt, f"multi-{len(nurse_ids)}")
    try:
        updated_nurses_list = json.loads(updated_nurses_text)
        if not isinstance(updated_nurses_list, list):
            raise Exception("Expected array of nurse objects")
    except json.JSONDecodeError as e:
        raise Exception(f"Bedrock returned invalid JSON: {e}")

    updated_data = json.loads(json.dumps(original_data))
    for updated_nurse in updated_nurses_list:
        uid = updated_nurse.get("nurse_id")
        if uid in target_nurses:
            updated_data = _replace_nurse_in_dataset(updated_data, uid, updated_nurse)
    return updated_data


# --- Demand Update Function ---
def _update_demand(original_data, instruction):
    """
    Update the hospital demand JSON based on Bedrock AI instructions.
    Safely parses JSON output even if Bedrock adds extra text or trailing commas.
    """
    prompt = f"""
You are updating the hospital demand data. Return ONLY valid JSON. Do not add extra text or comments. Use double quotes for keys..

Instruction: {instruction}

Current demand data:
{json.dumps(original_data, indent=2)}

Return the updated demand JSON ONLY, without extra text or formatting errors. Remember to use double quotes for keys.
"""

    response_text = _call_bedrock_agent(prompt, f"demand-{datetime.now().strftime('%H%M%S')}")
    
    # --- Safely extract and parse JSON ---
    updated_data = _parse_bedrock_json(response_text)
    return updated_data


def _parse_bedrock_json(response_text):
    # Extract the JSON object (first { to last })
    match = re.search(r'\{.*\}', response_text, re.DOTALL)
    if not match:
        raise Exception("No JSON object found in Bedrock response")
    json_text = match.group()

    # Remove trailing commas before } or ]
    json_text = re.sub(r',\s*(\}|\])', r'\1', json_text)

    # Ensure keys are double-quoted (basic attempt)
    # This handles keys like: Full-Morning: { "min": 3 }
    json_text = re.sub(r'(\s*)([a-zA-Z0-9_-]+)\s*:', r'\1"\2":', json_text)

    try:
        return json.loads(json_text)
    except json.JSONDecodeError as e:
        raise Exception(f"Bedrock returned malformed JSON after cleaning: {e}")


# --- Bedrock Call ---
def _call_bedrock_agent(prompt, session_suffix):
    response = agent_runtime.invoke_agent(
        agentId=AGENT_ID,
        agentAliasId=AGENT_ALIAS_ID,
        sessionId=f"update-{session_suffix}-{datetime.now().strftime('%H%M%S')}",
        inputText=prompt
    )
    output_text = ""
    for event in response.get("completion", []):
        if "chunk" in event:
            output_text += event["chunk"]["bytes"].decode("utf-8")
    return output_text


# --- Helper Functions ---
def _find_nurse(data, nurse_id):
    if isinstance(data, list):
        for nurse in data:
            if nurse.get("nurse_id") == nurse_id:
                return nurse
    elif isinstance(data, dict):
        if "nurses" in data:
            for nurse in data["nurses"]:
                if nurse.get("nurse_id") == nurse_id:
                    return nurse
        elif nurse_id in data:
            return data[nurse_id]
    return None


def _replace_nurse_in_dataset(original_data, nurse_id, updated_nurse):
    updated_data = json.loads(json.dumps(original_data))
    if isinstance(updated_data, list):
        for i, nurse in enumerate(updated_data):
            if nurse.get("nurse_id") == nurse_id:
                updated_data[i] = updated_nurse
                return updated_data
    elif isinstance(updated_data, dict):
        if "nurses" in updated_data:
            for i, nurse in enumerate(updated_data["nurses"]):
                if nurse.get("nurse_id") == nurse_id:
                    updated_data["nurses"][i] = updated_nurse
                    return updated_data
        elif nurse_id in updated_data:
            updated_data[nurse_id] = updated_nurse
            return updated_data
    return original_data


def _count_records(data):
    if isinstance(data, list):
        return len(data)
    elif isinstance(data, dict):
        if "nurses" in data:
            return len(data["nurses"])
        else:
            return len(data)
    return 0


def _response(message: str, **kwargs):
    body = {"message": message}
    body.update(kwargs)
    return {"statusCode": 200, "body": json.dumps(body)}
