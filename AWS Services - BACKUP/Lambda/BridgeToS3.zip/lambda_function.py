import json
import boto3
import datetime

s3 = boto3.client("s3")
BUCKET_NAME = "hospital-roster-data"
FOLDER_NAME = "lex-update"

def lambda_handler(event, context):
    """
    Lambda for Lex V2 (Fulfillment only):
    - Extracts slots from sessionState
    - Creates structured instruction payload
    - Returns structured response
    """
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    session_id = event.get("sessionId", "unknown")
    filename = f"{FOLDER_NAME}/full_lex_event_{session_id}_{timestamp}.json"

    print(f"DEBUG - Full event: {json.dumps(event)}")

    # Extract from sessionState (the actual intent being processed)
    session_state = event.get("sessionState", {})
    intent = session_state.get("intent", {})
    intent_name = intent.get("name")
    slots = intent.get("slots", {})

    # Extract slot values
    slot_values = {}
    for slot_name, slot_data in slots.items():
        if slot_data and slot_data.get("value"):
            slot_values[slot_name] = slot_data["value"]["interpretedValue"]

    nurse_id = slot_values.get("nurse_id")

    print(f"DEBUG - Intent: {intent_name}")
    print(f"DEBUG - Extracted slots: {json.dumps(slot_values, indent=2)}")

    # Build structured payload
    payload = _build_payload(intent_name, nurse_id.upper(), slot_values)

    print(f"DEBUG - Final Payload: {json.dumps(payload, indent=2)}")

    # Save structured payload to S3
    payload_filename = f"{FOLDER_NAME}/structured_payload_{session_id}_{timestamp}.json"
    try:
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=payload_filename,
            Body=json.dumps(payload, indent=2),
            ContentType="application/json"
        )
        print(f"DEBUG - Structured payload saved to s3://{BUCKET_NAME}/{payload_filename}")
    except Exception as e:
        print(f"ERROR - Failed to save structured payload: {str(e)}")

    return _lex_success_response(intent_name, f"Successfully processed {intent_name} for nurse {nurse_id}")


def _build_payload(intent_name, nurse_id, slots):
    """
    Map each intent into structured instruction format
    """
    payload = {
        "target_file": "nurse",
        "nurse_id": nurse_id,
        "instruction": None
    }

    if intent_name == "UpdatePreferredIntent":
        # From your example: preferences = "evening", nurse_id = "n001"
        preferences = slots.get("preferences", "").title()  # Capitalize first letter
        payload["instruction"] = f"change nurse {nurse_id} preferences to {preferences}"

    elif intent_name == "UpdateUnavailabilityIntent":
        # Example: "change nurse N002 unavailability to Mon-Evening"
        start_date = slots.get("start_date", "")
        end_date = slots.get("end_date", "")
        start_day = slots.get("start_day", "")
        end_day = slots.get("end_day", "")

        if start_day and end_day:
            # Generate all day-shift combinations between start_day and end_day
            unavailability_slots = _generate_day_shift_combinations(start_day, end_day)
            slots_text = ", ".join(unavailability_slots)

        if start_day and end_day and start_day and end_day:
            payload["instruction"] = f"change nurse {nurse_id} unavailability to {slots_text}-{end_day}:{start_date} to {end_date}"
        elif start_day and end_day:
            payload["instruction"] = f"change nurse {nurse_id} unavailability to {slots_text}"
        elif start_date and end_date:
            payload["instruction"] = f"change nurse {nurse_id} unavailability from {start_date} to {end_date}"
        else:
            payload["instruction"] = f"update nurse {nurse_id} unavailability"

    elif intent_name == "UpdateLeaveIntent":
        leave_type = slots.get("leave", "")
        start_date = slots.get("start_date", "")
        end_date = slots.get("end_date", "")
        start_day = slots.get("start_day", "")
        end_day = slots.get("end_day", "")

        if start_day and end_day:
            # Generate all day-shift combinations between start_day and end_day
            unavailability_slots = _generate_day_shift_combinations(start_day, end_day)
            slots_text = ", ".join(unavailability_slots)

        payload["instruction"] = f"add {leave_type} leave for nurse {nurse_id} from {slots_text}:{start_date} to {end_date}"

    elif intent_name == "UpdateDemandIntent":
        # Handle demand updates differently
        payload["target_file"] = "demand"
        department = slots.get("department", "")
        day = slots.get("day", "")
        shift_type = slots.get("shift_type", "")
        min_staff = slots.get("min", "")
        max_staff = slots.get("max", "")
        payload["instruction"] = f"update demand for {department} {day} {shift_type} min={min_staff} max={max_staff}"

    else:
        payload["instruction"] = f"update nurse {nurse_id} with provided information"

    return payload


def _lex_success_response(intent_name, message):
    """Standard Lex V2 success response"""
    return {
        "sessionState": {
            "intent": {
                "name": intent_name,
                "state": "Fulfilled"
            },
            "dialogAction": {
                "type": "Close"
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ]
    }

def _generate_day_shift_combinations(start_day, end_day):
    """
    Generate all day-shift combinations between start_day and end_day
    Example: Monday to Wednesday -> Mon-Morning, Mon-Evening, Mon-Night, Tue-Morning, etc.
    """
    days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    day_abbreviations = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    shifts = ["Morning", "Evening", "Night"]
    
    # Find indices of start and end days
    try:
        start_idx = days_of_week.index(start_day.title())
        end_idx = days_of_week.index(end_day.title())
    except ValueError:
        # If day names don't match exactly, try abbreviations
        try:
            start_idx = day_abbreviations.index(start_day[:3].title())
            end_idx = day_abbreviations.index(end_day[:3].title())
        except ValueError:
            return [f"{start_day}-{end_day}"]  # Fallback if parsing fails
    
    combinations = []
    
    # Handle wrap-around (e.g., Friday to Monday)
    if end_idx < start_idx:
        # From start_day to end of week
        for i in range(start_idx, len(days_of_week)):
            for shift in shifts:
                combinations.append(f"{day_abbreviations[i]}-{shift}")
        # From beginning of week to end_day
        for i in range(0, end_idx + 1):
            for shift in shifts:
                combinations.append(f"{day_abbreviations[i]}-{shift}")
    else:
        # Normal range (no wrap-around)
        for i in range(start_idx, end_idx + 1):
            for shift in shifts:
                combinations.append(f"{day_abbreviations[i]}-{shift}")
    
    return combinations